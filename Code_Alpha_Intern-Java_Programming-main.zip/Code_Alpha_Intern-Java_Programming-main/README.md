# Code Alpha - Java Programming Internship
Task 1 : Student Grade Tracker - 
Developed a program that allows a teacher to enter students' grades and compute their average, highest, and lowest scores.

Task 2 : Online Quiz Platform - 
Developed a program that allows students to take online Java quiz and computes their total quiz score at the end.

Task 3 : Hotel Reservation System - 
Built a Hotel Reservation System that allows users to search for available rooms, make reservations, check in and check out rooms.
